# DnD Tools

Hi there! :)

This project is dedicated to the creation of DnD (Dungeons and Dragons) tools that could be useful to either GMs or players.

As of now, I only have a basic terminal dice roller, but I'm planning on expanding the following points:

- Name generator
- Spell list

And some homebrew tools, such as:

- Enemy balancer
- (...) (Still looking for other ideas that might come up!)




#### Developed by:

- [@pipschroma](https://github.com/pipschroma)

